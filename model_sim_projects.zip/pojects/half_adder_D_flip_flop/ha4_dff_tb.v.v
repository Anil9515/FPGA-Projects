module ha4_dff_tb;

reg clk;
reg rst;
reg [3:0] A;
reg [3:0] B;

wire [3:0] Sum;
wire [3:0] Carry;
wire [3:0] stored_sum;

ha4_dff uut (
    .clk(clk),
    .rst(rst),
    .A(A),
    .B(B),
    .Sum(Sum),
    .Carry(Carry),
    .stored_sum(stored_sum)
);

// Clock generation
always #5 clk = ~clk;

initial begin

$display("==================================================");
    $display("     4-BIT HALF ADDER WITH 4 D FLIP-FLOPS");
    $display("==================================================");
    $display("Time  A     B     Sum   Carry  Stored_Sum");
    $display("--------------------------------------------------");

$monitor("%4t  %b  %b  %b  %b  %b",
             $time, A, B, Sum, Carry, stored_sum);

clk = 0;
    rst = 1;
    A = 0;
    B = 0;
    #10;

// Release reset
    rst = 0;

// Test 1
    A = 4'b0101;
    B = 4'b0011;
    #10;

// Test 2
    A = 4'b1111;
    B = 4'b1010;
    #10;

// Test 3
    A = 4'b1010;
    B = 4'b0101;
    #10;

// Test 4
    A = 4'b1100;
    B = 4'b0011;
    #10;

// Apply reset
    rst = 1;
    #10;

$display("==================================================");
    $display("           SIMULATION COMPLETED");
    $display("==================================================");

    $finish;

end

endmodule