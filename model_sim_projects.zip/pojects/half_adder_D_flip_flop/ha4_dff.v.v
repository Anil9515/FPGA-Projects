`timescale 1ns/1ps

module ha4_dff (
    input clk,
    input rst,
    input [3:0] A,
    input [3:0] B,
    output [3:0] Sum,
    output [3:0] Carry,
    output reg [3:0] stored_sum
);

wire [3:0] sum_comb;
wire [3:0] carry_comb;

// 4-bit Half Adder
assign sum_comb = A ^ B;
assign carry_comb = A & B;

assign Sum = sum_comb;
assign Carry = carry_comb;

// Four D Flip-Flops
always @(posedge clk or posedge rst) begin
    if (rst)
        stored_sum <= 4'b0000;
    else
        stored_sum <= sum_comb;
end

endmodule