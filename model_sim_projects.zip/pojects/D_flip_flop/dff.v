`timescale 1ns/1ps

module dff (
    input [3:0] A,
    input [3:0] B,
    input clk,
    output reg [3:0] Sum,
    output reg Carry
);

reg [4:0] temp;

// Combinational Addition
always @(*) begin
    temp = {1'b0, A} + {1'b0, B};
end

// D Flip-Flop
always @(posedge clk) begin
    Sum   <= temp[3:0];
    Carry <= temp[4];
end

endmodule