`timescale 1ns/1ps

module dff_tb;

reg [3:0] A;
reg [3:0] B;
reg clk;

wire [3:0] Sum;
wire Carry;

dff uut (
    .A(A),
    .B(B),
    .clk(clk),
    .Sum(Sum),
    .Carry(Carry)
);

// Clock generation
always #5 clk = ~clk;

initial begin

    $display("================================================");
    $display("       4-BIT REGISTERED ADDER SIMULATION");
    $display("================================================");
    $display("Time   A      B      Sum    Carry");
    $display("------------------------------------------------");

    $monitor("%4t   %b   %b   %b    %b",
             $time, A, B, Sum, Carry);

    clk = 0;
    A = 4'b0000;
    B = 4'b0000;
    #10;

    // Test 1: 5 + 3 = 8
    A = 4'b0101;
    B = 4'b0011;
    #10;

    // Test 2: 15 + 1 = 16
    A = 4'b1111;
    B = 4'b0001;
    #10;

    // Test 3: 10 + 5 = 15
    A = 4'b1010;
    B = 4'b0101;
    #10;

    // Test 4: 15 + 15 = 30
    A = 4'b1111;
    B = 4'b1111;
    #10;

    // Test 5: 7 + 2 = 9
    A = 4'b0111;
    B = 4'b0010;
    #10;

    $display("================================================");
    $display("          SIMULATION COMPLETED");
    $display("================================================");

    $finish;

end

endmodule