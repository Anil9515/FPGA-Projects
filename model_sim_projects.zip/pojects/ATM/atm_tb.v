
`timescale 1ns/1ps

module atm_controller_tb;

    reg clk;
    reg reset;
    reg card_inserted;
    reg pin_valid;
    reg pin_invalid;
    reg balance_checked;
    reg withdraw;
    reg sufficient_balance;
    reg cash_dispensed;
    reg exit;

    wire card_reader;
    wire pin_check;
    wire balance_display;
    wire cash_dispenser;
    wire transaction_done;
    wire error;

    // Device under test
    atm_controller uut (
        .clk(clk),
        .reset(reset),
        .card_inserted(card_inserted),
        .pin_valid(pin_valid),
        .pin_invalid(pin_invalid),
        .balance_checked(balance_checked),
        .withdraw(withdraw),
        .sufficient_balance(sufficient_balance),
        .cash_dispensed(cash_dispensed),
        .exit(exit),
        .card_reader(card_reader),
        .pin_check(pin_check),
        .balance_display(balance_display),
        .cash_dispenser(cash_dispenser),
        .transaction_done(transaction_done),
        .error(error)
    );

    // 10 ns clock period
    always #5 clk = ~clk;

    initial begin
        // Initialize inputs
        clk = 1'b0;
        reset = 1'b1;
        card_inserted = 1'b0;
        pin_valid = 1'b0;
        pin_invalid = 1'b0;
        balance_checked = 1'b0;
        withdraw = 1'b0;
        sufficient_balance = 1'b0;
        cash_dispensed = 1'b0;
        exit = 1'b0;

        // Reset
        #12;
        reset = 1'b0;

        // Insert card
        @(negedge clk);
        card_inserted = 1'b1;
        @(negedge clk);
        card_inserted = 1'b0;

        // Validate PIN
        repeat (2) @(negedge clk);
        pin_valid = 1'b1;
        @(negedge clk);
        pin_valid = 1'b0;

        // Check balance
        repeat (2) @(negedge clk);
        balance_checked = 1'b1;
        @(negedge clk);
        balance_checked = 1'b0;

        // Withdraw with sufficient balance
        repeat (2) @(negedge clk);
        sufficient_balance = 1'b1;
        withdraw = 1'b1;
        @(negedge clk);
        withdraw = 1'b0;

        // Dispense cash
        repeat (2) @(negedge clk);
        cash_dispensed = 1'b1;
        @(negedge clk);
        cash_dispensed = 1'b0;

        // Check transaction completion
        @(negedge clk);
        if (transaction_done === 1'b1)
            $display("TEST PASSED: ATM transaction completed!");
        else
            $display("TEST FAILED: Transaction not completed.");

        // Exit transaction
        @(negedge clk);
        exit = 1'b1;
        @(negedge clk);
        exit = 1'b0;

        // Test invalid PIN
        card_inserted = 1'b1;
        @(negedge clk);
        card_inserted = 1'b0;

        repeat (2) @(negedge clk);
        pin_invalid = 1'b1;
        @(negedge clk);
        pin_invalid = 1'b0;

        repeat (1) @(negedge clk);
        if (error === 1'b1)
            $display("TEST PASSED: Invalid PIN detected!");
        else
            $display("TEST FAILED: Invalid PIN error not detected.");

        // Exit error state
        @(negedge clk);
        exit = 1'b1;
        @(negedge clk);
        exit = 1'b0;

        #10;
        $finish;
    end

    // Display state and outputs
    initial begin
        $monitor(
            "Time=%0t | State=%b | Card=%b | PIN=%b | Balance=%b | Cash=%b | Done=%b | Error=%b",
            $time, uut.state, card_reader, pin_check,
            balance_display, cash_dispenser,
            transaction_done, error
        );
    end

endmodule
