
module atm_controller (
    input wire clk,
    input wire reset,
    input wire card_inserted,
    input wire pin_valid,
    input wire pin_invalid,
    input wire balance_checked,
    input wire withdraw,
    input wire sufficient_balance,
    input wire cash_dispensed,
    input wire exit,

    output reg card_reader,
    output reg pin_check,
    output reg balance_display,
    output reg cash_dispenser,
    output reg transaction_done,
    output reg error
);

    // Moore FSM state encoding
    parameter IDLE      = 3'b000,
              CARD      = 3'b001,
              PIN       = 3'b010,
              BALANCE   = 3'b011,
              WITHDRAW  = 3'b100,
              DISPENSE  = 3'b101,
              DONE      = 3'b110,
              ERROR     = 3'b111;

    reg [2:0] state, next_state;

    // State register
    always @(posedge clk or posedge reset) begin
        if (reset)
            state <= IDLE;
        else
            state <= next_state;
    end

    // Next-state logic
    always @(*) begin
        next_state = state;

        case (state)
            IDLE:
                if (card_inserted)
                    next_state = CARD;

            CARD:
                next_state = PIN;

            PIN:
                if (pin_valid)
                    next_state = BALANCE;
                else if (pin_invalid)
                    next_state = ERROR;

            BALANCE:
                if (balance_checked)
                    next_state = WITHDRAW;

            WITHDRAW:
                if (withdraw && sufficient_balance)
                    next_state = DISPENSE;
                else if (withdraw && !sufficient_balance)
                    next_state = ERROR;

            DISPENSE:
                if (cash_dispensed)
                    next_state = DONE;

            DONE:
                if (exit)
                    next_state = IDLE;

            ERROR:
                if (exit)
                    next_state = IDLE;

            default:
                next_state = IDLE;
        endcase
    end

    // Moore output logic
    always @(*) begin
        card_reader      = 1'b0;
        pin_check        = 1'b0;
        balance_display  = 1'b0;
        cash_dispenser   = 1'b0;
        transaction_done = 1'b0;
        error            = 1'b0;

        case (state)
            CARD:
                card_reader = 1'b1;

            PIN:
                pin_check = 1'b1;

            BALANCE:
                balance_display = 1'b1;

            DISPENSE:
                cash_dispenser = 1'b1;

            DONE:
                transaction_done = 1'b1;

            ERROR:
                error = 1'b1;

            default: ;
        endcase
    end

endmodule
