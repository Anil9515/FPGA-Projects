
`timescale 1ns/1ps

module riscv_5stage (
    input wire clk,
    input wire reset
);

    // Memories and register file
    reg [31:0] pc;
    reg [31:0] instruction_mem [0:63];
    reg [31:0] data_mem        [0:63];
    reg [31:0] registers       [0:31];

    integer i;

    // ==================================================
    // STAGE 1: INSTRUCTION FETCH (IF)
    // ==================================================

    reg [31:0] if_id_instruction;
    reg [31:0] if_id_pc;

    // ==================================================
    // STAGE 2: INSTRUCTION DECODE (ID)
    // ==================================================

    wire [6:0] opcode = if_id_instruction[6:0];
    wire [4:0] rd     = if_id_instruction[11:7];
    wire [2:0] funct3 = if_id_instruction[14:12];
    wire [4:0] rs1    = if_id_instruction[19:15];
    wire [4:0] rs2    = if_id_instruction[24:20];
    wire [6:0] funct7 = if_id_instruction[31:25];

    wire [31:0] read_data1 =
        (rs1 == 0) ? 32'd0 : registers[rs1];

    wire [31:0] read_data2 =
        (rs2 == 0) ? 32'd0 : registers[rs2];

    wire [31:0] imm_i =
        {{20{if_id_instruction[31]}},
         if_id_instruction[31:20]};

    wire [31:0] imm_s =
        {{20{if_id_instruction[31]}},
         if_id_instruction[31:25],
         if_id_instruction[11:7]};

    wire [31:0] imm_b =
        {{19{if_id_instruction[31]}},
         if_id_instruction[31],
         if_id_instruction[7],
         if_id_instruction[30:25],
         if_id_instruction[11:8],
         1'b0};

    reg [31:0] id_ex_pc;
    reg [31:0] id_ex_data1;
    reg [31:0] id_ex_data2;
    reg [31:0] id_ex_imm;
    reg [4:0]  id_ex_rd;
    reg [2:0]  id_ex_funct3;
    reg [6:0]  id_ex_funct7;
    reg [6:0]  id_ex_opcode;

    reg id_ex_reg_write;
    reg id_ex_mem_read;
    reg id_ex_mem_write;
    reg id_ex_mem_to_reg;
    reg id_ex_alu_src;
    reg id_ex_branch;

    reg dec_reg_write;
    reg dec_mem_read;
    reg dec_mem_write;
    reg dec_mem_to_reg;
    reg dec_alu_src;
    reg dec_branch;
    reg [31:0] dec_imm;

    always @(*) begin
        dec_reg_write   = 1'b0;
        dec_mem_read    = 1'b0;
        dec_mem_write   = 1'b0;
        dec_mem_to_reg  = 1'b0;
        dec_alu_src     = 1'b0;
        dec_branch      = 1'b0;
        dec_imm         = 32'd0;

        case (opcode)
            7'b0110011: begin // ADD, SUB, AND, OR
                dec_reg_write = 1'b1;
            end

            7'b0010011: begin // ADDI
                dec_reg_write = 1'b1;
                dec_alu_src = 1'b1;
                dec_imm = imm_i;
            end

            7'b0000011: begin // LW
                if (funct3 == 3'b010) begin
                    dec_reg_write = 1'b1;
                    dec_mem_read = 1'b1;
                    dec_mem_to_reg = 1'b1;
                    dec_alu_src = 1'b1;
                    dec_imm = imm_i;
                end
            end

            7'b0100011: begin // SW
                if (funct3 == 3'b010) begin
                    dec_mem_write = 1'b1;
                    dec_alu_src = 1'b1;
                    dec_imm = imm_s;
                end
            end

            7'b1100011: begin // BEQ
                if (funct3 == 3'b000) begin
                    dec_branch = 1'b1;
                    dec_imm = imm_b;
                end
            end

            default: begin
            end
        endcase
    end

    // ==================================================
    // STAGE 3: EXECUTE (EX)
    // ==================================================

    reg [31:0] ex_mem_alu_result;
    reg [31:0] ex_mem_store_data;
    reg [4:0]  ex_mem_rd;

    reg ex_mem_reg_write;
    reg ex_mem_mem_read;
    reg ex_mem_mem_write;
    reg ex_mem_mem_to_reg;

    reg [31:0] ex_alu_result;
    reg [31:0] ex_operand2;
    reg ex_branch_taken;
    reg [31:0] ex_branch_target;

    always @(*) begin
        ex_operand2 = id_ex_alu_src ?
                      id_ex_imm : id_ex_data2;

        ex_alu_result = 32'd0;
        ex_branch_taken = 1'b0;
        ex_branch_target = id_ex_pc + id_ex_imm;

        case (id_ex_opcode)
            7'b0110011: begin
                case (id_ex_funct3)
                    3'b000: begin
                        if (id_ex_funct7 == 7'b0100000)
                            ex_alu_result =
                                id_ex_data1 - id_ex_data2;
                        else
                            ex_alu_result =
                                id_ex_data1 + id_ex_data2;
                    end

                    3'b111:
                        ex_alu_result =
                            id_ex_data1 & id_ex_data2;

                    3'b110:
                        ex_alu_result =
                            id_ex_data1 | id_ex_data2;

                    default:
                        ex_alu_result = 32'd0;
                endcase
            end

            7'b0010011: begin // ADDI
                ex_alu_result =
                    id_ex_data1 + ex_operand2;
            end

            7'b0000011: begin // LW address
                ex_alu_result =
                    id_ex_data1 + id_ex_imm;
            end

            7'b0100011: begin // SW address
                ex_alu_result =
                    id_ex_data1 + id_ex_imm;
            end

            7'b1100011: begin // BEQ
                ex_branch_taken =
                    (id_ex_data1 == id_ex_data2);
            end

            default:
                ex_alu_result = 32'd0;
        endcase
    end

    // ==================================================
    // STAGE 4: MEMORY ACCESS (MEM)
    // ==================================================

    reg [31:0] mem_wb_alu_result;
    reg [31:0] mem_wb_read_data;
    reg [4:0]  mem_wb_rd;

    reg mem_wb_reg_write;
    reg mem_wb_mem_to_reg;

    wire [31:0] mem_read_data =
        data_mem[ex_mem_alu_result[7:2]];

    // ==================================================
    // STAGE 5: WRITE BACK (WB)
    // ==================================================

    wire [31:0] wb_data =
        mem_wb_mem_to_reg ?
        mem_wb_read_data : mem_wb_alu_result;

    always @(posedge clk) begin
        if (!reset) begin
            if (mem_wb_reg_write && (mem_wb_rd != 0))
                registers[mem_wb_rd] <= wb_data;

            registers[0] <= 32'd0;
        end
    end

    // ==================================================
    // PIPELINE REGISTERS AND CONTROL
    // ==================================================

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            pc <= 32'd0;

            if_id_instruction <= 32'h00000013;
            if_id_pc <= 32'd0;

            id_ex_pc <= 32'd0;
            id_ex_data1 <= 32'd0;
            id_ex_data2 <= 32'd0;
            id_ex_imm <= 32'd0;
            id_ex_rd <= 5'd0;
            id_ex_funct3 <= 3'd0;
            id_ex_funct7 <= 7'd0;
            id_ex_opcode <= 7'd0;

            id_ex_reg_write <= 1'b0;
            id_ex_mem_read <= 1'b0;
            id_ex_mem_write <= 1'b0;
            id_ex_mem_to_reg <= 1'b0;
            id_ex_alu_src <= 1'b0;
            id_ex_branch <= 1'b0;

            ex_mem_alu_result <= 32'd0;
            ex_mem_store_data <= 32'd0;
            ex_mem_rd <= 5'd0;

            ex_mem_reg_write <= 1'b0;
            ex_mem_mem_read <= 1'b0;
            ex_mem_mem_write <= 1'b0;
            ex_mem_mem_to_reg <= 1'b0;

            mem_wb_alu_result <= 32'd0;
            mem_wb_read_data <= 32'd0;
            mem_wb_rd <= 5'd0;
            mem_wb_reg_write <= 1'b0;
            mem_wb_mem_to_reg <= 1'b0;

            for (i = 0; i < 32; i = i + 1)
                registers[i] <= 32'd0;

        end else begin

            // IF: Fetch next instruction
            if (ex_branch_taken && id_ex_branch) begin
                pc <= ex_branch_target;
                if_id_instruction <= 32'h00000013;
                if_id_pc <= 32'd0;

                // Flush the instruction in Decode
                id_ex_reg_write <= 1'b0;
                id_ex_mem_read <= 1'b0;
                id_ex_mem_write <= 1'b0;
                id_ex_mem_to_reg <= 1'b0;
                id_ex_branch <= 1'b0;
                id_ex_alu_src <= 1'b0;
                id_ex_opcode <= 7'd0;
                id_ex_rd <= 5'd0;
                id_ex_data1 <= 32'd0;
                id_ex_data2 <= 32'd0;
                id_ex_imm <= 32'd0;
                id_ex_pc <= 32'd0;
                id_ex_funct3 <= 3'd0;
                id_ex_funct7 <= 7'd0;
            end else begin
                if_id_instruction <= instruction_mem[pc[7:2]];
                if_id_pc <= pc;
                pc <= pc + 32'd4;

                // ID: Decode and read registers
                id_ex_pc <= if_id_pc;
                id_ex_data1 <= read_data1;
                id_ex_data2 <= read_data2;
                id_ex_imm <= dec_imm;
                id_ex_rd <= rd;
                id_ex_funct3 <= funct3;
                id_ex_funct7 <= funct7;
                id_ex_opcode <= opcode;

                id_ex_reg_write <= dec_reg_write;
                id_ex_mem_read <= dec_mem_read;
                id_ex_mem_write <= dec_mem_write;
                id_ex_mem_to_reg <= dec_mem_to_reg;
                id_ex_alu_src <= dec_alu_src;
                id_ex_branch <= dec_branch;
            end

            // EX: Transfer ALU result and controls
            ex_mem_alu_result <= ex_alu_result;
            ex_mem_store_data <= id_ex_data2;
            ex_mem_rd <= id_ex_rd;

            ex_mem_reg_write <= id_ex_reg_write;
            ex_mem_mem_read <= id_ex_mem_read;
            ex_mem_mem_write <= id_ex_mem_write;
            ex_mem_mem_to_reg <= id_ex_mem_to_reg;

            // MEM: Store data and capture load data
            if (ex_mem_mem_write)
                data_mem[ex_mem_alu_result[7:2]]
                    <= ex_mem_store_data;

            mem_wb_alu_result <= ex_mem_alu_result;
            mem_wb_read_data <= mem_read_data;
            mem_wb_rd <= ex_mem_rd;
            mem_wb_reg_write <= ex_mem_reg_write;
            mem_wb_mem_to_reg <= ex_mem_mem_to_reg;
        end
    end

endmodule
