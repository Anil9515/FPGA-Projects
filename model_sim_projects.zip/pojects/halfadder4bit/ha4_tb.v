
`timescale 1ns/1ps

module ha4_tb;

reg [3:0] A;
reg [3:0] B;

wire [3:0] Sum;
wire [3:0] Carry;

ha4 dut (
    .A(A),
    .B(B),
    .Sum(Sum),
    .Carry(Carry)
);

initial begin

    $display("Time\t A\t B\t Sum\t Carry");

    $monitor("%0t\t %b\t %b\t %b\t %b",
             $time, A, B, Sum, Carry);

    A = 4'b0000; B = 4'b0000;
    #10;

    A = 4'b0101; B = 4'b0011;
    #10;

    A = 4'b1010; B = 4'b0101;
    #10;

    A = 4'b1111; B = 4'b0000;
    #10;

    A = 4'b1111; B = 4'b1111;
    #10;

    $finish;

end

endmodule
