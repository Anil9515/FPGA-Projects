
`timescale 1ns/1ps

module ha4 (
    input [3:0] A,
    input [3:0] B,
    output reg [3:0] Sum,
    output reg [3:0] Carry
);

always @(*) begin

    Sum = 4'b0000;
    Carry = 4'b0000;

    // Half Adder operation
    Sum = A ^ B;
    Carry = A & B;

end

endmodule
