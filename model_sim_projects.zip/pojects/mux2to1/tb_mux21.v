module mux2to1_tb;

reg A;
reg B;
reg sel;

wire Y;

mux2to1 uut (
    .A(A),
    .B(B),
    .sel(sel),
    .Y(Y)
);

initial begin

$display("==================================");
    $display("    2-TO-1 MUX SIMULATION");
    $display("==================================");
    $display("Time   A   B   Sel   Y");
    $display("----------------------------------");

$monitor("%4t   %b   %b    %b    %b",
             $time, A, B, sel, Y);

// Test 1
    A = 0; B = 0; sel = 0;
    #10;

// Test 2
    A = 0; B = 1; sel = 0;
    #10;

// Test 3
    A = 1; B = 0; sel = 1;
    #10;

// Test 4
    A = 1; B = 1; sel = 1;
    #10;

// Test 5
    A = 1; B = 0; sel = 0;
    #10;

// Test 6
    A = 0; B = 1; sel = 1;
    #10;

$display("==================================");
    $display("    SIMULATION COMPLETED");
    $display("==================================");

    $finish;

end

endmodule