`timescale 1ns/1ps

module mux2to1 (
    input A,
    input B,
    input sel,
    output reg Y
);

always @(*) begin

    // 2-to-1 Multiplexer
    if (sel == 1'b0)
        Y = A;
    else
        Y = B;

end

endmodule